@Transactional(dataSource = "primaryDataSource")
public void saveEmployee(Employee employee) {
    // ...
}

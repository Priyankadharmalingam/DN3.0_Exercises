package com.library.repository;

public class BookRepository {
    // Book repository methods will go here
}
